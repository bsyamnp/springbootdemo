package kz.narxoz.springbootdemo.service.impl;

public @interface NotEmpty {
    String message();
}
