package kz.narxoz.springbootdemo.service.impl;

public @interface Email {
}
