package kz.narxoz.springbootdemo.service.impl;

import kz.narxoz.springbootdemo.entity.Employee;
import kz.narxoz.springbootdemo.repository.EmployeeRepository;
import kz.narxoz.springbootdemo.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
 @Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    EmployeeRepository employeeRepository;

    @Override
    public List<Employee> findAllEmployees() {

        return employeeRepository.findAll();
    }

     @Override
     public Employee addEmployee(Employee employee) {
         return null;
     }


     @Override
    public Employee findOneById(Long id) {

        return employeeRepository.findById(id).orElse(null);
     }

     @Override
     public void deleteEmployee(Long id){

        employeeRepository.deleteById(id);
     }
 }
