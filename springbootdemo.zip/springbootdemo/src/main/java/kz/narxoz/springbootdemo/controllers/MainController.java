package kz.narxoz.springbootdemo.controllers;

import kz.narxoz.springbootdemo.model.Product;
import kz.narxoz.springbootdemo.model.Users;
import kz.narxoz.springbootdemo.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class MainController {

    @Autowired
    private ProductRepository productRepository;



    @GetMapping(value = "/mainpage")
    public String mainPage(Model model ){
        model.addAttribute("currentUser", getCurrentUser());
        List<Product> products = productRepository.findAll();
        model.addAttribute("products", products);
        return "mainpage";
    }
    @GetMapping(value = "/")
    public String indexPage(@org.jetbrains.annotations.NotNull Model model){
        model.addAttribute("currentUser", getCurrentUser());;
        return "index";
    }
    @PostMapping(value = "/addproduct")
    public String addProductPage(@RequestParam(name = "product_name") String name,
                                 @RequestParam(name = "product_model") String model,
                                 @RequestParam(name = "product_price") int price){

        Product product = new Product();
        product.setName(name);
        product.setModel(model);
        product.setPrice(price);

        productRepository.save(product);
        return "redirect:/mainpage";
    }

    @PostMapping(value = "/saveproduct")
    public String saveProduct(@RequestParam(name = "product_id") Long id,
                              @RequestParam(name = "product_name") String name,
                              @RequestParam(name = "product_model") String model,
                              @RequestParam(name = "product_price") int price){

        Product product = productRepository.findById(id).orElse(null);

        if (product!=null){
            product.setName(name);
            product.setModel(model);
            product.setPrice(price);
            productRepository.save(product);
            return "redirect:/details/"+id;
        }
        return "redirect:/";
    }

    @PostMapping(value = "/deleteproduct")
    public String deleteProduct(@RequestParam(name = "product_id") Long id){

        Product product = productRepository.findById(id).orElse(null);
        if (product!=null){
            productRepository.delete(product);
        }
        return "redirect:/";
    }

    @GetMapping(value = "/details/{id}")
    public String details(@PathVariable(name = "id") Long id, Model model){
        Product product = productRepository.findById(id).orElse(null);
        model.addAttribute("product", product);
        return "details";
    }

    @GetMapping(value = "/login")
    public String login(Model model){
        model.addAttribute("currentUser", getCurrentUser());
        return "login";
    }

    @GetMapping(value = "/register")
    public String register(Model model){
        model.addAttribute("currentUser", getCurrentUser());
        return "register";
    }

    @GetMapping(value = "/profile")
    @PreAuthorize("isAuthenticated()")
    public String profile(Model model){
        model.addAttribute("currentUser", getCurrentUser());
        return "profile";
    }

    @GetMapping(value = "/adminpanel")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN')")
    public String admin(Model model){
        model.addAttribute("currentUser", getCurrentUser());
        return "adminpanel";
    }

    @GetMapping(value = "/403")
    public String accessDeniedPage(Model model){
        model.addAttribute("currentUser", getCurrentUser());
        return "403";
    }

    private Users getCurrentUser(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if(!(authentication instanceof AnonymousAuthenticationToken)){
            Users currentUser = (Users) authentication.getPrincipal();
            return currentUser;
        }
        return null;
    }

    @GetMapping(value = "/details")
    public String details(Model model){
        model.addAttribute("currentUser", getCurrentUser());
        return "details";
    }

}

