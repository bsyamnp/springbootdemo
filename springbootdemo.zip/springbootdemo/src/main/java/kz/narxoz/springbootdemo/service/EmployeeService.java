package kz.narxoz.springbootdemo.service;

import kz.narxoz.springbootdemo.entity.Employee;

import java.util.List;

public interface EmployeeService {

    List<Employee> findAllEmployees();
    Employee addEmployee(Employee employee);
    Employee findOneById(Long id);
    void deleteEmployee(Long id);

}
