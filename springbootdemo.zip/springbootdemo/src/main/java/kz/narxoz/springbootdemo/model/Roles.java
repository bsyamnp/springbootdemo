package kz.narxoz.springbootdemo.model;

import lombok.*;
import org.springframework.security.core.GrantedAuthority;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "t_roles")

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Roles implements GrantedAuthority {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "role")
    private String role;
    @ManyToMany(mappedBy = "roles")
    private List<Users> users = new ArrayList<>();

    @Override
    public String getAuthority() {
        return role;
    }

    public void setName(String role_admin) {
    }
}
