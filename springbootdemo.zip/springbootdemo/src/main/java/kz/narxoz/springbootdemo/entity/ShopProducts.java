package kz.narxoz.springbootdemo.entity;

import lombok.*;

import javax.persistence.*;


@Entity
@Getter
@Setter
@Table(name = "t_shop")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShopProducts {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id", nullable = false)
    private Long id;
    @Column(name = "name", nullable = false)
    private String name;
    @Column(name = "model", nullable = false)
    private String model;
    @Column(name = "price", nullable = false)
    private int price;

}
