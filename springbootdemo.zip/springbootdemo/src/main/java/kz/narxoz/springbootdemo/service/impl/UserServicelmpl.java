package kz.narxoz.springbootdemo.service.impl;

import kz.narxoz.springbootdemo.model.Roles;
import kz.narxoz.springbootdemo.model.Users;
import kz.narxoz.springbootdemo.repository.RoleRepository;
import kz.narxoz.springbootdemo.repository.UserRepository;
import kz.narxoz.springbootdemo.service.UserService;
import org.jetbrains.annotations.NotNull;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
class UserServiceImpl extends UserService implements kz.narxoz.springbootdemo.service.impl.UserService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    public UserServiceImpl(UserRepository userRepository,
                           RoleRepository roleRepository,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
    }

@Override
    public void saveUser(@NotNull UserDto userDto) {
        Users user = new Users();
        user.setName(userDto.getFirstName() + " " + userDto.getLastName());
        user.setEmail(userDto.getEmail());
        // encrypt the password using spring security
        user.setPassword(passwordEncoder.encode(userDto.getPassword()));

        Roles roles = roleRepository.findByName("ROLE_ADMIN");
        if(roles == null){
            roles = checkRoleExist();
            user.setRoles(of(new Roles[]{roles}));
        } else {
            user.setRoles(of(new Roles[]{roles}));
        }
        userRepository.save(user);
    }

    private List<Roles> of(Roles[] roles) {
        return null;
    }

    @Override
    public List<UserDto> findAllUsers() {
        List<Users> users = userRepository.findAll();
        return users.stream()
                .map((user) -> mapToUserDto(user))
                .collect(Collectors.toList());
    }

    private UserDto mapToUserDto(Users user){
        UserDto userDto = new UserDto();
        String[] str = user.getName().split(" ");
        userDto.setFirstName(str[0]);
        userDto.setLastName(str[1]);
        userDto.setEmail(user.getEmail());
        return userDto;
    }

    private Roles checkRoleExist(){
        Roles role = new Roles();
        role.setName("ROLE_ADMIN");
        return roleRepository.save(role);
    }
}