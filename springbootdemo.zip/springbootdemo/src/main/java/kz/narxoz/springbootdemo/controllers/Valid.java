package kz.narxoz.springbootdemo.controllers;

public @interface Valid {
}
