package kz.narxoz.springbootdemo.service.impl;

import kz.narxoz.springbootdemo.model.Users;

public interface UserService {
    static void findAllUsers() {

    }


    static Users findUserByEmail(String email) {
        return null;
    }

    static void saveUser(UserDto userDto) {
    }
}
