package kz.narxoz.springbootdemo.controllers;
import kz.narxoz.springbootdemo.entity.Employee;
import kz.narxoz.springbootdemo.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.ui.Model;

@Controller
public class EmployeeController {
    @Autowired
    EmployeeService employeeService;

    @GetMapping("/employees")
    public String employees(Model model) {
        model.addAttribute("employees", employeeService.findAllEmployees());
        return "employees";
    }

    @GetMapping("addemployee")
    public String addEmployeeForm(Model model) {
        Employee employee = new Employee();
        model.addAttribute("employee", employee);
        return "addemployee";
    }

    @PostMapping("/employees")
    public String addStudent(@ModelAttribute("employee") Employee employee){
        employeeService.addEmployee(employee);
        return "redirect:/employees";
    }

    @GetMapping("/employees/update/{id}")
    public String updateEmployeeForm(@PathVariable("id") Long id, Model model){
        model.addAttribute("student", employeeService.findOneById(id));
        return "updateemployee";
    }

    @PostMapping("/employees/update/{id}")
    public String updateEmployeeForm(@PathVariable("id") Long id, @ModelAttribute("student") Employee employee){
        Employee existtingEmployee = employeeService.findOneById(id);
        existtingEmployee.setId(id);
        existtingEmployee.setFirstName(employee.getFirstName());
        existtingEmployee.setLastName(employee.getLastName());
        existtingEmployee.setEmail(employee.getEmail());
        employeeService.addEmployee(existtingEmployee);
        return "redirect:/employees";
    }
    @GetMapping("/employees/delete/{id}")
    public String deleteEmployee(@PathVariable("id") Long id){
        employeeService.deleteEmployee(id);
        return "redirect:/employees";
    }
}

