package kz.narxoz.springbootdemo.service;

import kz.narxoz.springbootdemo.model.Users;
import kz.narxoz.springbootdemo.model.Users;
import kz.narxoz.springbootdemo.repository.RoleRepository;
import kz.narxoz.springbootdemo.repository.UserRepository;
import kz.narxoz.springbootdemo.service.impl.UserDto;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public abstract class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Users user = userRepository.findByEmail(username);
        if(user != null){
            return user;
        }else {
            throw new UsernameNotFoundException("User not found");
        }
    }

    public abstract void saveUser(@NotNull UserDto userDto);

    public Users findUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public abstract List<UserDto> findAllUsers();
}
